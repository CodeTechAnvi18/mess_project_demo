import React from "react";
import { createBrowserRouter } from "react-router-dom";
import App from "./App";
import Footer from "./components/Footer";
import Header from "./components/Header";
import Dashboard from "./components/admin/Dashboard";
const router = createBrowserRouter([
  {
    path: "/",
    element: <App />,
    children: [
      {
        path: "/footer",
        element: <Footer />,
      },
      {
        path: "/header",
        element: <Header />,
      },
      {
        path: "/dashboard",
        element: <Dashboard />,
      },
    ],
  },
]);
export default router;
