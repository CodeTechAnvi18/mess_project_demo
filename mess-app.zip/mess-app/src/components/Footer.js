import React from 'react'

function Footer() {
  return (
    <div className="footer bg-black bg-gradient">
      <h5>&copy; All rights reserved to Gokhale Mess</h5>
    </div>
  );
}

export default Footer
